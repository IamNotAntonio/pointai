// Point.AI — Content Script
// Detecta portais acadêmicos e oferece importação de notas

;(function () {
  'use strict'

  const POINT_AI_URL = 'https://pointai-two.vercel.app'

  // ── Detecção de portal acadêmico ────────────────────────────────
  const URL_PATTERNS = [
    /siga[a]?\./i, /moodle\./i, /totvs\./i, /suagrade\./i,
    /sapiens\./i, /academico\./i, /siabi\./i, /sigac\./i,
    /aluno\..*\.edu/i, /portal\..*\.edu/i, /sistema\..*\.edu/i,
    /ava\./i, /AVA\./i, /intranet\..*edu/i, /sga\./i, /sgce\./i,
    /portal\.kroton/i, /portal\.anhanguera/i, /portal\.ampli/i,
    /graduacao\./i, /pos\./i,
  ]

  const CONTENT_KEYWORDS = [
    'nota final', 'média final', 'frequência', 'diário de classe',
    'avaliação parcial', 'conceito', 'aprovado', 'reprovado',
    'matrícula', 'disciplina cursada', 'grau',
  ]

  function isAcademicPortal() {
    // Skip Point.AI itself
    if (location.hostname.includes('pointai-two')) return false
    // Skip browser internal pages
    if (!location.hostname) return false

    if (URL_PATTERNS.some(p => p.test(location.hostname + location.pathname))) return true

    const bodyText = (document.body?.innerText || '').toLowerCase().slice(0, 3000)
    const hits = CONTENT_KEYWORDS.filter(k => bodyText.includes(k))
    return hits.length >= 2
  }

  // ── Extração de notas do DOM ─────────────────────────────────────
  function extrairTabelas() {
    const linhas = []
    const tables = Array.from(document.querySelectorAll('table'))

    const gradeWords = ['nota', 'grade', 'avaliação', 'prova', 'pontos', 'conceito', 'média']
    const absenceWords = ['falta', 'frequência', 'presença', 'ausência']

    for (const table of tables) {
      const headerText = Array.from(table.querySelectorAll('th, thead td'))
        .map(el => el.innerText.trim().toLowerCase())
        .join(' ')

      const isGradeTable = gradeWords.some(w => headerText.includes(w))
      const isAttendanceTable = absenceWords.some(w => headerText.includes(w))

      if (!isGradeTable && !isAttendanceTable) continue

      for (const row of Array.from(table.rows)) {
        const cells = Array.from(row.cells)
          .map(c => c.innerText.replace(/\s+/g, ' ').trim())
          .filter(c => c.length > 0)
        if (cells.length >= 2) linhas.push(cells.join('\t'))
      }
    }

    // Fallback: tentar capturar listas com matérias e notas
    if (linhas.length === 0) {
      const selectors = [
        '.disciplina', '.materia', '.subject', '.course',
        '[class*="grade"]', '[class*="nota"]', '[class*="disciplina"]',
        '[class*="subject"]', '[class*="course"]',
      ]
      for (const sel of selectors) {
        const els = document.querySelectorAll(sel)
        if (els.length > 0) {
          els.forEach(el => {
            const text = el.innerText.replace(/\s+/g, ' ').trim()
            if (text.length > 5 && text.length < 500) linhas.push(text)
          })
          break
        }
      }
    }

    // Último recurso: texto bruto da área de conteúdo principal
    if (linhas.length === 0) {
      const main = document.querySelector(
        'main, [role="main"], #main-content, #content, .content, .container'
      ) || document.body
      return main.innerText.slice(0, 5000)
    }

    return linhas.join('\n')
  }

  // ── UI: Botão flutuante ──────────────────────────────────────────
  function injetarBotao() {
    if (document.getElementById('pointai-fab')) return

    // Wrapper
    const wrap = document.createElement('div')
    wrap.id = 'pointai-fab-wrap'
    Object.assign(wrap.style, {
      position: 'fixed',
      bottom: '24px',
      right: '24px',
      zIndex: '2147483647',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'flex-end',
      gap: '10px',
      fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, sans-serif',
    })

    // Toast
    const toast = document.createElement('div')
    toast.id = 'pointai-toast'
    Object.assign(toast.style, {
      background: '#141414',
      color: '#f4f4f5',
      padding: '10px 14px',
      borderRadius: '10px',
      fontSize: '12px',
      lineHeight: '1.5',
      maxWidth: '260px',
      boxShadow: '0 8px 24px rgba(0,0,0,.4)',
      border: '1px solid rgba(34,197,94,.35)',
      display: 'none',
      textAlign: 'left',
      animation: 'pointai-fadein .2s ease',
    })
    wrap.appendChild(toast)

    // Botão principal
    const btn = document.createElement('button')
    btn.id = 'pointai-fab'
    btn.setAttribute('title', 'Importar notas para Point.AI')
    btn.innerHTML = `
      <svg width="17" height="17" viewBox="0 0 24 24" fill="none"
           stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
        <polyline points="17 8 12 3 7 8"/>
        <line x1="12" y1="3" x2="12" y2="15"/>
      </svg>
      <span style="font-size:13px;font-weight:700;letter-spacing:-.2px">Importar para Point.AI</span>
    `
    Object.assign(btn.style, {
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      padding: '11px 18px',
      background: 'linear-gradient(135deg,#1a7a4a,#22c55e)',
      color: 'white',
      border: 'none',
      borderRadius: '50px',
      cursor: 'pointer',
      boxShadow: '0 4px 20px rgba(26,122,74,.5)',
      transition: 'transform .15s, box-shadow .15s',
      whiteSpace: 'nowrap',
    })

    btn.addEventListener('mouseenter', () => {
      btn.style.transform = 'scale(1.05)'
      btn.style.boxShadow = '0 6px 28px rgba(26,122,74,.65)'
    })
    btn.addEventListener('mouseleave', () => {
      btn.style.transform = 'scale(1)'
      btn.style.boxShadow = '0 4px 20px rgba(26,122,74,.5)'
    })

    btn.addEventListener('click', () => {
      btn.disabled = true
      btn.style.opacity = '.7'
      btn.querySelector('span').textContent = 'Extraindo dados...'

      try {
        const dados = extrairTabelas()
        const fonte = { url: location.href, titulo: document.title }

        chrome.runtime.sendMessage(
          { type: 'SAVE_IMPORT_DATA', dados, fonte },
          (resp) => {
            btn.disabled = false
            btn.style.opacity = '1'
            btn.querySelector('span').textContent = 'Importar para Point.AI'

            if (resp?.ok) {
              mostrarToast(
                '✓ Dados capturados! O Point.AI foi aberto numa nova aba — clique em "Importar do portal" para confirmar.'
              )
            } else {
              mostrarToast('Erro ao capturar dados. Tente pela aba "Colar texto" no Point.AI.')
            }
          }
        )
      } catch (err) {
        btn.disabled = false
        btn.style.opacity = '1'
        btn.querySelector('span').textContent = 'Importar para Point.AI'
        mostrarToast('Erro ao ler a página. Tente pelo portal na opção Colar texto.')
      }
    })

    wrap.appendChild(btn)
    document.body.appendChild(wrap)

    // CSS de animação
    if (!document.getElementById('pointai-css')) {
      const style = document.createElement('style')
      style.id = 'pointai-css'
      style.textContent = `
        @keyframes pointai-fadein { from { opacity:0; transform:translateY(4px) } to { opacity:1; transform:translateY(0) } }
      `
      document.head.appendChild(style)
    }
  }

  function mostrarToast(msg, duracao = 5000) {
    const toast = document.getElementById('pointai-toast')
    if (!toast) return
    toast.textContent = msg
    toast.style.display = 'block'
    clearTimeout(toast._timer)
    toast._timer = setTimeout(() => { toast.style.display = 'none' }, duracao)
  }

  // Receber confirmação do background
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'IMPORT_QUEUED') {
      mostrarToast('✓ Notas capturadas! Abrindo Point.AI...')
    }
  })

  // ── Init ─────────────────────────────────────────────────────────
  function init() {
    if (!isAcademicPortal()) return
    injetarBotao()
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init)
  } else {
    init()
  }

  // Re-check em SPAs após navegação
  let lastUrl = location.href
  new MutationObserver(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href
      setTimeout(init, 800)
    }
  }).observe(document.body, { childList: true, subtree: true })
})()
